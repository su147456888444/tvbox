## CatVodOpen新源

#### 编译

```bash
npm install && npm run build
```
> 生成的dist文件发布到dist分支中


#### 新源地址
```text
gitee://Token@gitee.com/jadehh_743/TVSpider/dist/index.js.md5
github://Token@gitee.com/jadehh/TVSpider/dist/index.js.md5
```